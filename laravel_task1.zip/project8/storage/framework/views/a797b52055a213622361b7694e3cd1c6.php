<div class="modal" id="edit_modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content d-flex justify-content-center align-items-center">
            <form action="" id="edit_form" class="p-5">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <h5>Edit new course</h5>
                <div class="content">
                    <div class="form-input">
                        <label for="edit_name">Course Name</label>
                        <input class="info" type="text" name="edit_name" id="edit_name"
                            value="<?php echo e(old('edit_name')); ?>" required>
                    </div>
                </div>
                <?php $__errorArgs = ['edit_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <div class="content">
                    <div class="form-input">
                        <label for="edit_id">Kh course id</label>
                        <input class="info" type="text" name="edit_id" id="edit_id" value="<?php echo e(old('edit_id')); ?>"
                            required>
                    </div>
                </div>
                <?php $__errorArgs = ['edit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <div class="content">
                    <div class="form-input">
                        <label for="edit_semester">Semester</label>
                        <input class="info" type="text" name="edit_semester" id="edit_semester"
                            value="<?php echo e(old('edit_semester')); ?>" required>
                    </div>
                </div>
                <?php $__errorArgs = ['edit_semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <div class="content">
                    <div class="form-input">
                        <label for="edit_status">Status</label>
                        <label>
                            <input type="radio" class="edit_status" id="active" name="status" value="active"> Active
                            <input type="radio" class="edit_status" id="non-active" name="status" value="non-active"> Non-Active
                        </label>
                    </div>
                </div>
                <?php $__errorArgs = ['edit_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>

                <div class="buttons">
                    <button class="close_modal btn shadow-lg" style="background-color: rgb(212, 212, 212)"
                        type="reset">Close</button>
                    <button type="submit" class="btn bg-primary shadow-lg" style="color: white">Save
                        course</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/templates/edit_course_modal.blade.php ENDPATH**/ ?>