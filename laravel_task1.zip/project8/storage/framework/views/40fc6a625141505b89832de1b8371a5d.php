<div class="modal" id="profile_modal">
    <div class="modal-dialog" role="document">
        <div class="d-flex align-items-center">
            <div class="modal-content p-5">
                <h3>Profile</h3>
                <label for="" class="form-control">Name : <?php echo e(Auth::user()->name); ?></label>
                <label for="" class="form-control">Email : <?php echo e(Auth::user()->email); ?></label>
                <label for="" class="form-control">Logged in as :
                    <?php if($data=Auth::user()->roles->pluck('name')): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="mx-2" for=""><?php echo e($role); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </label>
                <br>
                <button type="button" class="close_modal btn btn-danger">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/templates/profile_modal.blade.php ENDPATH**/ ?>