<style>
    .glyphicon {
        cursor: pointer;
    }
</style>
<div class="card">
    
    <div class="card-body">
        <table class="table text-center table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>
                        <div class="d-flex align-items-center justify-content-center">
                            Course Name
                            <div>
                                <span class="name_ase glyphicon">&#xe253;</span><br>
                                <span class="name_desc glyphicon">&#xe252;</span>
                            </div>
                        </div>
                    </th>
                    <th>
                        <div class="d-flex align-items-center justify-content-center">
                            Course Id
                            <div class="mx-2">
                                <span class="id_ase glyphicon">&#xe253;</span><br>
                                <span class="id_desc glyphicon">&#xe252;</span>
                            </div>
                        </div>
                    </th>
                    <th>
                        <div class="d-flex align-items-center justify-content-center">
                            Semester
                            <div class="mx-2">
                                <span class="semester_ase glyphicon">&#xe253;</span><br>
                                <span class="semester_desc glyphicon">&#xe252;</span>
                            </div>
                        </div>
                    </th>
                    <th>
                        <div class="d-flex align-items-center justify-content-center">
                            Status
                            <div class="mx-2">
                                <span class="glyphicon"></span><br>
                                <span class="glyphicon"></span>
                            </div>
                        </div>
                    </th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit course', 'delete course'])): ?>
                        <th>
                            <div class="d-flex align-items-center justify-content-center">
                                Actions
                                <div class="mx-2">
                                    <span class="glyphicon"></span><br>
                                    <span class="glyphicon"></span>
                                </div>
                            </div>
                        </th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody id="body">
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($data->id); ?>">
                        <td class="table_name_sort">
                            <a href="https://www.youtube.com/results?search_query=<?php echo e($data->name); ?>"
                                target="_blank"><?php echo e($data->name); ?></a>
                        </td>
                        <td><?php echo e($data->course_id); ?></td>
                        <td><?php echo e($data->semester); ?></td>
                        <?php if($data->status == 'active'): ?>
                            <td style="color: green;">
                                <div class="d-flex align-items-center justify-content-center">
                                    <span class="glyphicon glyphicon-ok green-circle mx-2"></span>
                                    Active
                                </div>
                            </td>
                        <?php else: ?>
                            <td style="color: red;">
                                <div class="d-flex align-items-center justify-content-center">
                                    <span class="glyphicon glyphicon-remove red-circle mx-2"></span>
                                    Non-Active
                                </div>
                            </td>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit course', 'delete course'])): ?>
                            <td>
                                <div class="d-flex align-items-center justify-content-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit course')): ?>
                                        <button class="edit btn btn-warning mx-1" style="width: 100%">Edit</button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete course')): ?>
                                        <button class="delete btn btn-danger mx-1" style="width: 100%">Delete</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<br>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/templates/sort_show_table_data.blade.php ENDPATH**/ ?>