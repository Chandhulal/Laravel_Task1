<?php if (isset($component)) { $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cover_page_layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cover_page_layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('components.course_home_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container">
        <div class="card shadow-lg">
            <div class="card-body d-flex">
                <div class="m-5">
                    <img src="storage/img/cover3.jpg" alt="img" style="width: 400px;height:300px;border-radius:10px">
                </div>
                <div class="p-5 d-flex align-items-center"
                    style="font-family: 'Times New Roman', Times, serif;font-size:large">
                    Choosing to study at this college offers you a chance to receive a high-quality education in a
                    supportive and dynamic environment. With experienced faculty, modern facilities, and a focus on
                    practical learning, the college ensures that students are well-prepared for their future careers.
                    The diverse academic programs, coupled with a range of extracurricular activities, foster personal
                    growth and development.
                </div>
            </div>
        </div>
    </div>
    <div class="container my-5">
        <div class="card shadow-lg">
            <div class="card-body d-flex">
                <div class="p-5 d-flex align-items-center"
                    style="font-family: 'Times New Roman', Times, serif;font-size:large">
                    Education is the foundation of personal and societal growth. It equips individuals with knowledge,
                    skills, and values, empowering them to make informed decisions and contribute meaningfully to their
                    communities. Beyond academics, education fosters critical thinking, creativity, and emotional
                    intelligence, shaping the future of individuals and nations alike.
                </div>
                <div class="m-5">
                    <img src="storage/img/cover2.jpg" alt="img"
                        style="width: 400px;height:300px;border-radius:10px">
                </div>
            </div>
        </div>
    </div>
    <br>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $attributes = $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $component = $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/templates/course_home.blade.php ENDPATH**/ ?>