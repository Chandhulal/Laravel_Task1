<?php if (isset($component)) { $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cover_page_layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cover_page_layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('components.course_home_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container my-5">
            <div class="card shadow-lg" style="width: 500px;">
                <div class="card-body">
                    <span>Name : <?php echo e($mail->user->name); ?></span><br>
                    <span class="form-control">Message : <?php echo e($mail->message); ?></span>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $attributes = $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $component = $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/templates/faq_mails.blade.php ENDPATH**/ ?>