<?php if (isset($component)) { $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cover_page_layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cover_page_layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('components.course_home_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container my-4">
        <h3>Mails</h3>
        <hr>
        <div class="row g-4">
            <?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-5">
                    <form action="" method="post" id="<?php echo e($mail->id); ?>" class="delete_faq_mail">
                        <div class="card shadow-lg" style="border-radius: 10px;">
                            <div class="card-body p-5">
                                <div class="d-flex justify-content-between">
                                    <span class="form-control mr-2">Name: <?php echo e($mail->user->name); ?></span>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button id="checked" class="btn btn-primary">Remove</button>
                                </div><br>
                                <textarea class="form-control" rows="5" readonly><?php echo e($mail->message); ?></textarea>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br>
    <script>
        $(document).ready(function() {
            $(document).on('submit', '.delete_faq_mail', function(e) {
                if (confirm('Confirm delete?')) {
                    e.preventDefault();
                    let id = $(this).closest('form')[0].id;
                    let closest_form = $(this).closest('form');

                    $.ajax({
                        url: '/delete_faq_mail/' + id,
                        type: 'delete',
                        data: closest_form.serialize(),
                        success: function(response) {

                            if (response == "deleted") {
                                closest_form.remove();
                                close_modal();
                            }
                        },
                    });
                } else {
                    e.preventDefault();
                }
            });

            function close_modal() {
                $('#support_form').find('#message').val("");
                $('#support_modal').hide();
            };
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $attributes = $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $component = $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/templates/admin_faq_mails.blade.php ENDPATH**/ ?>