<?php if (isset($component)) { $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cover_page_layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cover_page_layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        form {
            padding: 30px;
            border-radius: 10px;
            width: 400px;
        }

        h3 {
            text-align: center
        }

        img {
            width: 440px;
            height: 400px;
            border-radius: 20px;
        }
    </style>
    <div class="d-flex">
        <div class="d-flex justify-content-center align-items-center" style="width: 100%">
            <div class="d-flex justify-content-center align-items-center">
                <div>
                    <h3 style="font-family: 'Times New Roman', Times, serif">ES Courses</h3>
                    <img src="storage/img/cover1.jpg" alt="img">
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-center align-items-center m-5" style="width: 100%;">
            <div id="registration_form" style="display: none;height:500px">
                <div class="d-flex justify-content-center align-items-center">
                    <div style="margin-top:20px">
                        <?php if($errors->any()): ?>
                            <ul style="list-style-type: none; padding-left: 0;">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li
                                        style="background-color: #f8d7da; color: #721c24; padding: 10px; border: 1px solid #f5c6cb; margin-bottom: 5px;">
                                        <?php echo e($error); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <h3>Regisrtation</h3>
                        <form action="/user_registration" method="post" class="shadow-lg">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Name:</label>
                                <input type="text" class="form-control" name="name" id="name"
                                    value="<?php echo e(old('name')); ?>" required>
                            </div>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" name="email" id="email"
                                    value="<?php echo e(old('email')); ?>" required>
                            </div>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" name="password" id="password"
                                    value="<?php echo e(old('password')); ?>" required>
                            </div>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-group">
                                <label for="password_confirmation">Confirm password</label>
                                <input type="password" class="form-control" name="password_confirmation"
                                    id="password_confirmation" value="<?php echo e(old('cpassword')); ?>" required>
                            </div>
                            <?php $__errorArgs = ['cpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: rgb(231, 17, 17)"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="d-flex justify-content-center align-items-center my-4">
                                <button class="form-control bg-primary">Register</button>
                            </div>
                        </form>
                        <div class="d-flex justify-content-center align-items-center">
                            <button class="btn btn-outline-primary" onclick="login_form()">Existing user</button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="login_form" style="display: block;height:500px;">
                <div style="margin-top:100px">
                    <div>
                        <?php if($errors->any()): ?>
                            <ul style="list-style-type: none; padding-left: 0;">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li
                                        style="background-color: #f8d7da; color: #721c24; padding: 10px; border: 1px solid #f5c6cb; margin-bottom: 5px;">
                                        <?php echo e($error); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <ul style="list-style-type: none; padding-left: 0;">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li
                                        style="background-color: #f8d7da; color: #721c24; padding: 10px; border: 1px solid #f5c6cb; margin-bottom: 5px;">
                                        <?php echo e($error); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                        <?php endif; ?>

                        <h3>Login</h3>
                        <form action="/login_authentication" method="post" class="shadow-lg">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="form-group">
                                <label for="user_email">Email:</label>
                                <input type="text" class="form-control" name="user_email" id="user_email"
                                    value="<?php echo e(old('user_email')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="user_password">password:</label>
                                <input type="password" class="form-control" name="user_password" id="user_password"
                                    value="<?php echo e(old('user_password')); ?>" required>
                            </div>
                            <div class="d-flex justify-content-center align-items-center m-4">
                                <button type="submit" class="form-control bg-primary">Login</button>
                            </div>
                        </form>
                        <div class="d-flex justify-content-center align-items-center">
                            <button class="btn btn-outline-primary" onclick="registration_form()">New user</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function login_form() {
                document.getElementById('login_form').style.display = 'block';
                document.getElementById('registration_form').style.display = 'none';
            }

            function registration_form() {
                document.getElementById('login_form').style.display = 'none';
                document.getElementById('registration_form').style.display = 'block';
            }
        </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $attributes = $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $component = $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/user/user_registration.blade.php ENDPATH**/ ?>