<?php if (isset($component)) { $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cover_page_layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cover_page_layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <br>
    <style>
        th {
            text-align: center;
        }
    </style>
    <?php echo $__env->make('actions.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container my-5">
        <div class="col-md-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>User</h4>
                    <div class=" d-flex justify-content-end">
                        <a href="/users/create"><button class="btn btn-primary float-end">Add User</button></a>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Roles</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit user', 'delete user'])): ?>
                                <th>Action</th>
                            <?php endif; ?>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td>
                                        <?php if($data->getRoleNames()): ?>
                                            <?php $__currentLoopData = $data->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="mx-2"
                                                    for=""><?php echo e($role); ?></label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit user', 'delete user'])): ?>
                                        <td class="d-flex">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
                                                <div class="mx-2" style="width: 100%">
                                                    <a href="/users/<?php echo e($data->id); ?>/edit"><button class="btn btn-warning"
                                                            style="width: 100%">Edit</button></a>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete user')): ?>
                                                <div class="mx-2" style="width: 100%">
                                                    <form action="/users/<?php echo e($data->id); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button class="btn btn-danger" id="delete_user"
                                                            style="width: 100%">Delete</button>
                                                    </form>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $(document).on('click', '#delete_user', function(e) {
                console.log("hi");
                if (!confirm('Remove this user')) {
                    e.preventDefault();
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $attributes = $__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__attributesOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5)): ?>
<?php $component = $__componentOriginal4a8c302b4aedc3e62c6921e790d813f5; ?>
<?php unset($__componentOriginal4a8c302b4aedc3e62c6921e790d813f5); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\Laravel\project8\resources\views/actions/users/indux.blade.php ENDPATH**/ ?>